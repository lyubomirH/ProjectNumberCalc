namespace NumeralConverter
{
    internal static class Converter
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new ConverterForm());
        }
    }
}