﻿namespace NumeralConverter
{
    partial class ConverterForm
    {
        private System.ComponentModel.IContainer components = null;

        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelDecimalNumber = new Label();
            textBoxDecimalNumber = new TextBox();
            labelDecimalToBinary = new Label();
            textBoxDecimalToBinary = new TextBox();
            buttonDecimalToBinary = new Button();
            buttonDecimalToHex = new Button();
            textBoxDecimalToHex = new TextBox();
            labelDecimalToHex = new Label();
            buttonBinaryToHex = new Button();
            textBoxBinaryToHex = new TextBox();
            labelBinaryToHex = new Label();
            buttonBinaryToDecimal = new Button();
            textBoxBinaryToDecimal = new TextBox();
            labelBinaryToDecimal = new Label();
            textBoxBinaryNumber = new TextBox();
            labelBinaryNumber = new Label();
            buttonHexToBinary = new Button();
            textBoxHexToBinary = new TextBox();
            labelHexToBinary = new Label();
            buttonHexToDecimal = new Button();
            textBoxHexToDecimal = new TextBox();
            labelHexToDecimal = new Label();
            textBoxHexNumber = new TextBox();
            labelHexNumber = new Label();
            SuspendLayout();
            // 
            // labelDecimalNumber
            // 
            labelDecimalNumber.AutoSize = true;
            labelDecimalNumber.Location = new Point(14, 12);
            labelDecimalNumber.Name = "labelDecimalNumber";
            labelDecimalNumber.Size = new Size(125, 20);
            labelDecimalNumber.TabIndex = 0;
            labelDecimalNumber.Text = "Decimal Number:";
            // 
            // textBoxDecimalNumber
            // 
            textBoxDecimalNumber.Location = new Point(14, 36);
            textBoxDecimalNumber.Margin = new Padding(3, 4, 3, 4);
            textBoxDecimalNumber.Name = "textBoxDecimalNumber";
            textBoxDecimalNumber.Size = new Size(190, 27);
            textBoxDecimalNumber.TabIndex = 1;
            // 
            // labelDecimalToBinary
            // 
            labelDecimalToBinary.AutoSize = true;
            labelDecimalToBinary.Location = new Point(211, 12);
            labelDecimalToBinary.Name = "labelDecimalToBinary";
            labelDecimalToBinary.Size = new Size(73, 20);
            labelDecimalToBinary.TabIndex = 2;
            labelDecimalToBinary.Text = "To Binary:";
            // 
            // textBoxDecimalToBinary
            // 
            textBoxDecimalToBinary.Location = new Point(211, 36);
            textBoxDecimalToBinary.Margin = new Padding(3, 4, 3, 4);
            textBoxDecimalToBinary.Name = "textBoxDecimalToBinary";
            textBoxDecimalToBinary.ReadOnly = true;
            textBoxDecimalToBinary.Size = new Size(190, 27);
            textBoxDecimalToBinary.TabIndex = 3;
            textBoxDecimalToBinary.TextChanged += textBoxDecimalToBinary_TextChanged;
            // 
            // buttonDecimalToBinary
            // 
            buttonDecimalToBinary.Location = new Point(409, 36);
            buttonDecimalToBinary.Margin = new Padding(3, 4, 3, 4);
            buttonDecimalToBinary.Name = "buttonDecimalToBinary";
            buttonDecimalToBinary.Size = new Size(79, 31);
            buttonDecimalToBinary.TabIndex = 4;
            buttonDecimalToBinary.Text = "Convert";
            buttonDecimalToBinary.UseVisualStyleBackColor = true;
            buttonDecimalToBinary.Click += ButtonDecimalToBinary_Click;
            // 
            // buttonDecimalToHex
            // 
            buttonDecimalToHex.Location = new Point(409, 101);
            buttonDecimalToHex.Margin = new Padding(3, 4, 3, 4);
            buttonDecimalToHex.Name = "buttonDecimalToHex";
            buttonDecimalToHex.Size = new Size(79, 31);
            buttonDecimalToHex.TabIndex = 9;
            buttonDecimalToHex.Text = "Convert";
            buttonDecimalToHex.UseVisualStyleBackColor = true;
            buttonDecimalToHex.Click += ButtonDecimalToHex_Click;
            // 
            // textBoxDecimalToHex
            // 
            textBoxDecimalToHex.Location = new Point(211, 101);
            textBoxDecimalToHex.Margin = new Padding(3, 4, 3, 4);
            textBoxDecimalToHex.Name = "textBoxDecimalToHex";
            textBoxDecimalToHex.ReadOnly = true;
            textBoxDecimalToHex.Size = new Size(190, 27);
            textBoxDecimalToHex.TabIndex = 8;
            // 
            // labelDecimalToHex
            // 
            labelDecimalToHex.AutoSize = true;
            labelDecimalToHex.Location = new Point(211, 77);
            labelDecimalToHex.Name = "labelDecimalToHex";
            labelDecimalToHex.Size = new Size(58, 20);
            labelDecimalToHex.TabIndex = 7;
            labelDecimalToHex.Text = "To Hex:";
            // 
            // buttonBinaryToHex
            // 
            buttonBinaryToHex.Location = new Point(409, 251);
            buttonBinaryToHex.Margin = new Padding(3, 4, 3, 4);
            buttonBinaryToHex.Name = "buttonBinaryToHex";
            buttonBinaryToHex.Size = new Size(79, 31);
            buttonBinaryToHex.TabIndex = 17;
            buttonBinaryToHex.Text = "Convert";
            buttonBinaryToHex.UseVisualStyleBackColor = true;
            buttonBinaryToHex.Click += ButtonBinaryToHex_Click;
            // 
            // textBoxBinaryToHex
            // 
            textBoxBinaryToHex.Location = new Point(211, 251);
            textBoxBinaryToHex.Margin = new Padding(3, 4, 3, 4);
            textBoxBinaryToHex.Name = "textBoxBinaryToHex";
            textBoxBinaryToHex.ReadOnly = true;
            textBoxBinaryToHex.Size = new Size(190, 27);
            textBoxBinaryToHex.TabIndex = 16;
            // 
            // labelBinaryToHex
            // 
            labelBinaryToHex.AutoSize = true;
            labelBinaryToHex.Location = new Point(211, 227);
            labelBinaryToHex.Name = "labelBinaryToHex";
            labelBinaryToHex.Size = new Size(58, 20);
            labelBinaryToHex.TabIndex = 15;
            labelBinaryToHex.Text = "To Hex:";
            // 
            // buttonBinaryToDecimal
            // 
            buttonBinaryToDecimal.Location = new Point(409, 185);
            buttonBinaryToDecimal.Margin = new Padding(3, 4, 3, 4);
            buttonBinaryToDecimal.Name = "buttonBinaryToDecimal";
            buttonBinaryToDecimal.Size = new Size(79, 31);
            buttonBinaryToDecimal.TabIndex = 14;
            buttonBinaryToDecimal.Text = "Convert";
            buttonBinaryToDecimal.UseVisualStyleBackColor = true;
            buttonBinaryToDecimal.Click += ButtonBinaryToDecimal_Click;
            // 
            // textBoxBinaryToDecimal
            // 
            textBoxBinaryToDecimal.Location = new Point(211, 185);
            textBoxBinaryToDecimal.Margin = new Padding(3, 4, 3, 4);
            textBoxBinaryToDecimal.Name = "textBoxBinaryToDecimal";
            textBoxBinaryToDecimal.ReadOnly = true;
            textBoxBinaryToDecimal.Size = new Size(190, 27);
            textBoxBinaryToDecimal.TabIndex = 13;
            // 
            // labelBinaryToDecimal
            // 
            labelBinaryToDecimal.AutoSize = true;
            labelBinaryToDecimal.Location = new Point(211, 161);
            labelBinaryToDecimal.Name = "labelBinaryToDecimal";
            labelBinaryToDecimal.Size = new Size(87, 20);
            labelBinaryToDecimal.TabIndex = 12;
            labelBinaryToDecimal.Text = "To Decimal:";
            // 
            // textBoxBinaryNumber
            // 
            textBoxBinaryNumber.Location = new Point(14, 185);
            textBoxBinaryNumber.Margin = new Padding(3, 4, 3, 4);
            textBoxBinaryNumber.Name = "textBoxBinaryNumber";
            textBoxBinaryNumber.Size = new Size(190, 27);
            textBoxBinaryNumber.TabIndex = 11;
            // 
            // labelBinaryNumber
            // 
            labelBinaryNumber.AutoSize = true;
            labelBinaryNumber.Location = new Point(14, 161);
            labelBinaryNumber.Name = "labelBinaryNumber";
            labelBinaryNumber.Size = new Size(111, 20);
            labelBinaryNumber.TabIndex = 10;
            labelBinaryNumber.Text = "Binary Number:";
            // 
            // buttonHexToBinary
            // 
            buttonHexToBinary.Location = new Point(409, 396);
            buttonHexToBinary.Margin = new Padding(3, 4, 3, 4);
            buttonHexToBinary.Name = "buttonHexToBinary";
            buttonHexToBinary.Size = new Size(79, 31);
            buttonHexToBinary.TabIndex = 25;
            buttonHexToBinary.Text = "Convert";
            buttonHexToBinary.UseVisualStyleBackColor = true;
            buttonHexToBinary.Click += ButtonHexToBinary_Click;
            // 
            // textBoxHexToBinary
            // 
            textBoxHexToBinary.Location = new Point(211, 396);
            textBoxHexToBinary.Margin = new Padding(3, 4, 3, 4);
            textBoxHexToBinary.Name = "textBoxHexToBinary";
            textBoxHexToBinary.ReadOnly = true;
            textBoxHexToBinary.Size = new Size(190, 27);
            textBoxHexToBinary.TabIndex = 24;
            // 
            // labelHexToBinary
            // 
            labelHexToBinary.AutoSize = true;
            labelHexToBinary.Location = new Point(211, 372);
            labelHexToBinary.Name = "labelHexToBinary";
            labelHexToBinary.Size = new Size(73, 20);
            labelHexToBinary.TabIndex = 23;
            labelHexToBinary.Text = "To Binary:";
            // 
            // buttonHexToDecimal
            // 
            buttonHexToDecimal.Location = new Point(409, 331);
            buttonHexToDecimal.Margin = new Padding(3, 4, 3, 4);
            buttonHexToDecimal.Name = "buttonHexToDecimal";
            buttonHexToDecimal.Size = new Size(79, 31);
            buttonHexToDecimal.TabIndex = 22;
            buttonHexToDecimal.Text = "Convert";
            buttonHexToDecimal.UseVisualStyleBackColor = true;
            buttonHexToDecimal.Click += ButtonHexToDecimal_Click;
            // 
            // textBoxHexToDecimal
            // 
            textBoxHexToDecimal.Location = new Point(211, 331);
            textBoxHexToDecimal.Margin = new Padding(3, 4, 3, 4);
            textBoxHexToDecimal.Name = "textBoxHexToDecimal";
            textBoxHexToDecimal.ReadOnly = true;
            textBoxHexToDecimal.Size = new Size(190, 27);
            textBoxHexToDecimal.TabIndex = 21;
            textBoxHexToDecimal.TextChanged += textBoxHexToDecimal_TextChanged;
            // 
            // labelHexToDecimal
            // 
            labelHexToDecimal.AutoSize = true;
            labelHexToDecimal.Location = new Point(211, 307);
            labelHexToDecimal.Name = "labelHexToDecimal";
            labelHexToDecimal.Size = new Size(87, 20);
            labelHexToDecimal.TabIndex = 20;
            labelHexToDecimal.Text = "To Decimal:";
            // 
            // textBoxHexNumber
            // 
            textBoxHexNumber.Location = new Point(14, 331);
            textBoxHexNumber.Margin = new Padding(3, 4, 3, 4);
            textBoxHexNumber.Name = "textBoxHexNumber";
            textBoxHexNumber.Size = new Size(190, 27);
            textBoxHexNumber.TabIndex = 19;
            textBoxHexNumber.TextChanged += textBoxHexNumber_TextChanged;
            // 
            // labelHexNumber
            // 
            labelHexNumber.AutoSize = true;
            labelHexNumber.Location = new Point(14, 307);
            labelHexNumber.Name = "labelHexNumber";
            labelHexNumber.Size = new Size(96, 20);
            labelHexNumber.TabIndex = 18;
            labelHexNumber.Text = "Hex Number:";
            // 
            // ConverterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(503, 444);
            Controls.Add(buttonHexToBinary);
            Controls.Add(textBoxHexToBinary);
            Controls.Add(labelHexToBinary);
            Controls.Add(buttonHexToDecimal);
            Controls.Add(textBoxHexToDecimal);
            Controls.Add(labelHexToDecimal);
            Controls.Add(textBoxHexNumber);
            Controls.Add(labelHexNumber);
            Controls.Add(buttonBinaryToHex);
            Controls.Add(textBoxBinaryToHex);
            Controls.Add(labelBinaryToHex);
            Controls.Add(buttonBinaryToDecimal);
            Controls.Add(textBoxBinaryToDecimal);
            Controls.Add(labelBinaryToDecimal);
            Controls.Add(textBoxBinaryNumber);
            Controls.Add(labelBinaryNumber);
            Controls.Add(buttonDecimalToHex);
            Controls.Add(textBoxDecimalToHex);
            Controls.Add(labelDecimalToHex);
            Controls.Add(buttonDecimalToBinary);
            Controls.Add(textBoxDecimalToBinary);
            Controls.Add(labelDecimalToBinary);
            Controls.Add(textBoxDecimalNumber);
            Controls.Add(labelDecimalNumber);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            Name = "ConverterForm";
            Text = "Converter";
            Load += ConverterForm_Load;
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private Label labelDecimalNumber;
        private TextBox textBoxDecimalNumber;
        private Label labelDecimalToBinary;
        private TextBox textBoxDecimalToBinary;
        private Button buttonDecimalToBinary;
        private Button buttonDecimalToHex;
        private TextBox textBoxDecimalToHex;
        private Label labelDecimalToHex;
        private Button buttonBinaryToHex;
        private TextBox textBoxBinaryToHex;
        private Label labelBinaryToHex;
        private Button buttonBinaryToDecimal;
        private TextBox textBoxBinaryToDecimal;
        private Label labelBinaryToDecimal;
        private TextBox textBoxBinaryNumber;
        private Label labelBinaryNumber;
        private Button buttonHexToBinary;
        private TextBox textBoxHexToBinary;
        private Label labelHexToBinary;
        private Button buttonHexToDecimal;
        private TextBox textBoxHexToDecimal;
        private Label labelHexToDecimal;
        private TextBox textBoxHexNumber;
        private Label labelHexNumber;
    }
}