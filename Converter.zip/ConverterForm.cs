using System.Text;

namespace NumeralConverter
{
    public partial class ConverterForm : Form
    {
        public ConverterForm()
        {
            this.InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void ButtonDecimalToBinary_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxDecimalNumber.Text))
            {
                ShowErrorBox();
                return;
            }

            if (int.TryParse(textBoxDecimalNumber.Text, out int decimalNumber))
            {
                textBoxDecimalToBinary.Text = ConvertFromBaseTen(decimalNumber, 2);
            }
            else
            {
                ShowConversionError("Please enter a valid decimal number");
            }
        }

        private void ButtonDecimalToHex_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxDecimalNumber.Text))
            {
                ShowErrorBox();
                return;
            }

            if (int.TryParse(textBoxDecimalNumber.Text, out int decimalNumber))
            {
                textBoxDecimalToHex.Text = ConvertFromBaseTen(decimalNumber, 16);
            }
            else
            {
                ShowConversionError("Please enter a valid decimal number");
            }
        }

        private void ButtonBinaryToDecimal_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxBinaryNumber.Text))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                int decimalNumber = ConvertToBaseTen(textBoxBinaryNumber.Text, 2);
                textBoxBinaryToDecimal.Text = decimalNumber.ToString();
            }
            catch
            {
                ShowConversionError("Please enter a valid binary number (0-1 only)");
            }
        }

        private void ButtonBinaryToHex_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxBinaryNumber.Text))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                string hexResult = ConvertBinaryToHex(textBoxBinaryNumber.Text);
                textBoxBinaryToHex.Text = hexResult.ToUpper();
            }
            catch
            {
                ShowConversionError("Please enter a valid binary number (0-1 only)");
            }
        }

        private void ButtonHexToDecimal_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxHexNumber.Text))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                int decimalNumber = ConvertToBaseTen(textBoxHexNumber.Text, 16);
                textBoxHexToDecimal.Text = decimalNumber.ToString();
            }
            catch (ArgumentException ex)
            {
                ShowConversionError(ex.Message);
            }
            catch
            {
                ShowConversionError("Please enter a valid hexadecimal number (0-9, A-F)");
            }
        }

        private void ButtonHexToBinary_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxHexNumber.Text))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                string binaryResult = ConvertHexToBinary(textBoxHexNumber.Text);
                textBoxHexToBinary.Text = binaryResult;
            }
            catch (ArgumentException ex)
            {
                ShowConversionError(ex.Message);
            }
            catch
            {
                ShowConversionError("Please enter a valid hexadecimal number (0-9, A-F)");
            }
        }

        private string ConvertFromBaseTen(int number, int toBase)
        {
            return NumeralConverter.ConvertFromBaseTen(number, toBase);
        }

        private int ConvertToBaseTen(string number, int fromBase)
        {
            return NumeralConverter.ConvertToBaseTen(number, fromBase);
        }

        private string ConvertBinaryToHex(string binaryText)
        {
            return NumeralConverter.ConvertBinaryToHex(binaryText);
        }

        private string ConvertHexToBinary(string hexText)
        {
            return NumeralConverter.ConvertHexToBinary(hexText);
        }

        private void ShowErrorBox()
        {
            MessageBox.Show(
                "Text box cannot be empty",
                "Error!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }

        private void ShowConversionError(string message)
        {
            MessageBox.Show(message, "Error!",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void ConverterForm_Load(object sender, EventArgs e)
        {

        }

        private void textBoxDecimalToBinary_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxHexToDecimal_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxHexNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }

    public class NumeralConverter
    {
        public static string ConvertFromBaseTen(int number, int targetBase)
        {
            if (number == 0) return "0";

            Stack<char> digits = new Stack<char>();

            while (number > 0)
            {
                int remainder = number % targetBase;
                char digit;

                if (remainder < 10)
                {
                    digit = (char)('0' + remainder);
                }
                else
                {
                    digit = (char)('A' + (remainder - 10));
                }

                digits.Push(digit);
                number /= targetBase;
            }

            StringBuilder result = new StringBuilder();
            while (digits.Count > 0)
            {
                result.Append(digits.Pop());
            }

            return result.ToString();
        }

        public static int ConvertToBaseTen(string number, int sourceBase)
        {
            int result = 0;
            int power = 1;

            for (int i = number.Length - 1; i >= 0; i--)
            {
                char digit = number[i];
                int value;

                if (sourceBase == 16)
                {
                    if (!IsValidHexDigit(digit))
                    {
                        throw new ArgumentException("Hexadecimal digits must be uppercase (0-9, A-F)");
                    }
                }

                if (char.IsDigit(digit))
                {
                    value = digit - '0';
                }
                else
                {
                    value = 10 + (digit - 'A');
                }

                if (value >= sourceBase)
                {
                    throw new ArgumentException($"Invalid digit '{digit}' for base {sourceBase}");
                }

                result += value * power;
                power *= sourceBase;
            }

            return result;
        }

        private static bool IsValidHexDigit(char digit)
        {
            return (digit >= '0' && digit <= '9') || (digit >= 'A' && digit <= 'F');
        }

        public static string ConvertBinaryToHex(string binary)
        {
            int decimalValue = ConvertToBaseTen(binary, 2);
            return ConvertFromBaseTen(decimalValue, 16);
        }

        public static string ConvertHexToBinary(string hex)
        {
            int decimalValue = ConvertToBaseTen(hex, 16);
            return ConvertFromBaseTen(decimalValue, 2);
        }
    }
}