using System.Text;

namespace NumeralConverter
{
    public partial class ConverterForm : Form
    {
        // Add these fields to reference your actual controls
        private TextBox inputTextBox;
        private TextBox resultTextBox;

        public ConverterForm()
        {
            this.InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

            // Initialize the textboxes - you'll need to set these to your actual control names
            // Replace "textBoxInput" and "textBoxResult" with your actual control names
            this.inputTextBox = this.Controls.Find("textBoxInput", true).FirstOrDefault() as TextBox;
            this.resultTextBox = this.Controls.Find("textBoxResult", true).FirstOrDefault() as TextBox;

            // Alternative: If you know the exact names, you can assign them directly
            // this.inputTextBox = textBoxInput; // Uncomment if your control is named textBoxInput
            // this.resultTextBox = textBoxResult; // Uncomment if your control is named textBoxResult
        }

        private void ButtonDecimalToBinary_Click(object sender, EventArgs e)
        {
            string inputText = GetInputText();
            if (string.IsNullOrWhiteSpace(inputText))
            {
                ShowErrorBox();
                return;
            }

            if (int.TryParse(inputText, out int decimalNumber))
            {
                SetResultText(ConvertFromBaseTen(decimalNumber, 2));
            }
            else
            {
                ShowConversionError("Please enter a valid decimal number");
            }
        }

        private void ButtonDecimalToHex_Click(object sender, EventArgs e)
        {
            string inputText = GetInputText();
            if (string.IsNullOrWhiteSpace(inputText))
            {
                ShowErrorBox();
                return;
            }

            if (int.TryParse(inputText, out int decimalNumber))
            {
                SetResultText(ConvertFromBaseTen(decimalNumber, 16));
            }
            else
            {
                ShowConversionError("Please enter a valid decimal number");
            }
        }

        private void ButtonBinaryToDecimal_Click(object sender, EventArgs e)
        {
            string inputText = GetInputText();
            if (string.IsNullOrWhiteSpace(inputText))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                int decimalNumber = ConvertToBaseTen(inputText, 2);
                SetResultText(decimalNumber.ToString());
            }
            catch
            {
                ShowConversionError("Please enter a valid binary number");
            }
        }

        private void ButtonBinaryToHex_Click(object sender, EventArgs e)
        {
            string inputText = GetInputText();
            if (string.IsNullOrWhiteSpace(inputText))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                string hexResult = ConvertBinaryToHex(inputText);
                SetResultText(hexResult);
            }
            catch
            {
                ShowConversionError("Please enter a valid binary number");
            }
        }

        private void ButtonHexToDecimal_Click(object sender, EventArgs e)
        {
            string inputText = GetInputText();
            if (string.IsNullOrWhiteSpace(inputText))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                int decimalNumber = ConvertToBaseTen(inputText, 16);
                SetResultText(decimalNumber.ToString());
            }
            catch
            {
                ShowConversionError("Please enter a valid hexadecimal number");
            }
        }

        private void ButtonHexToBinary_Click(object sender, EventArgs e)
        {
            string inputText = GetInputText();
            if (string.IsNullOrWhiteSpace(inputText))
            {
                ShowErrorBox();
                return;
            }

            try
            {
                string binaryResult = ConvertHexToBinary(inputText);
                SetResultText(binaryResult);
            }
            catch
            {
                ShowConversionError("Please enter a valid hexadecimal number");
            }
        }

        // Helper methods to handle textbox access
        private string GetInputText()
        {
            if (inputTextBox != null)
                return inputTextBox.Text;

            // Fallback: try to find the control dynamically
            var textBox = this.Controls.Find("textBoxInput", true).FirstOrDefault() as TextBox;
            return textBox?.Text ?? string.Empty;
        }

        private void SetResultText(string text)
        {
            if (resultTextBox != null)
            {
                resultTextBox.Text = text;
                return;
            }

            // Fallback: try to find the control dynamically
            var textBox = this.Controls.Find("textBoxResult", true).FirstOrDefault() as TextBox;
            if (textBox != null)
            {
                textBox.Text = text;
            }
        }
        private string ConvertFromBaseTen(int number, int toBase)
        {
            return NumeralConverter.ConvertFromBaseTen(number, toBase);
        }

        private int ConvertToBaseTen(string number, int fromBase)
        {
            return NumeralConverter.ConvertToBaseTen(number, fromBase);
        }

        private string ConvertBinaryToHex(string binaryText)
        {
            return NumeralConverter.ConvertBinaryToHex(binaryText);
        }

        private string ConvertHexToBinary(string hexText)
        {
            return NumeralConverter.ConvertHexToBinary(hexText);
        }

        private void ShowErrorBox()
        {
            MessageBox.Show(
                "Text box cannot be empty",
                "Error!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }

        private void ShowConversionError(string message)
        {
            MessageBox.Show(message, "Error!",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    // NumeralConverter class remains the same as before
    public class NumeralConverter
    {
        public static string ConvertFromBaseTen(int number, int targetBase)
        {
            if (number == 0) return "0";

            Stack<char> digits = new Stack<char>();

            while (number > 0)
            {
                int remainder = number % targetBase;
                char digit;

                if (remainder < 10)
                {
                    digit = (char)('0' + remainder);
                }
                else
                {
                    digit = (char)('A' + (remainder - 10));
                }

                digits.Push(digit);
                number /= targetBase;
            }

            StringBuilder result = new StringBuilder();
            while (digits.Count > 0)
            {
                result.Append(digits.Pop());
            }

            return result.ToString();
        }

        public static int ConvertToBaseTen(string number, int sourceBase)
        {
            int result = 0;
            int power = 1;

            for (int i = number.Length - 1; i >= 0; i--)
            {
                char digit = number[i];
                int value;

                if (char.IsDigit(digit))
                {
                    value = digit - '0';
                }
                else
                {
                    value = 10 + (digit - 'A');
                }

                result += value * power;
                power *= sourceBase;
            }

            return result;
        }

        public static string ConvertBinaryToHex(string binary)
        {
            int decimalValue = ConvertToBaseTen(binary, 2);
            return ConvertFromBaseTen(decimalValue, 16);
        }

        public static string ConvertHexToBinary(string hex)
        {
            int decimalValue = ConvertToBaseTen(hex, 16);
            return ConvertFromBaseTen(decimalValue, 2);
        }
    }
}